
// defining variables from AWS
import AWS from 'aws-sdk';

AWS.config.update({
    region: 'ap-southeast-2'
})

import {buildResponse} from '../utils/util.js';
// for encrypting password
import bcrypt from 'bcryptjs';
import {generateToken} from '../utils/auth.js';
const dynamodb = new AWS.DynamoDB.DocumentClient();
const skatersTable = 'skaters';

async function login(skater) {
    const derbyName = skater.derbyName;
    const password = skater.password;
    // check for derbyname and password, return required message
    if (!derbyName || !password) {
        return buildResponse(401, {
            message: 'username and password are required'
        })
    }

    // try to get a skater from the database
    const dynamoUser = await getSkater(derbyName);
    if (!dynamoUser || !dynamoUser.derbyName) {
        return buildResponse(403, { message: 'user does not exist (edit me!)'});
    }
    
    // check their password
    if(!bcrypt.compareSync(password, dynamoUser.password)) {
        return buildResponse(403, { message: 'password is incorrect (edit me!)'});
    }

    // if everything matches, define a skaterInfo object
    const skaterInfo = {
        derbyName: dynamoUser.derbyName
    }

    // generate token
    const token = generateToken(skaterInfo);

    //  create response with skaterInfo and token
    const response = {
        skater: skaterInfo,
        token: token
    }

    return buildResponse(200, response);

}

// get the derbyName from the dynamodb table
async function getSkater(derbyName) {
    const params = {
        TableName: skatersTable,
        Key: {
            derbyName: derbyName
        }
    }

    return await dynamodb.get(params).promise().then(response => {
        return response.Item;
    }, error => {
        console.error('There is an error getting user: ', error);
    })
}

// module.exports.login = login;
export { login as login};