import {buildResponse} from '../utils/util.js';
import {verifyToken} from '../utils/auth.js';

function verify(requestBody) {
    // check the request body has a skater and derby name
    if (!requestBody.skater || !requestBody.skater.derbyName || !requestBody.token){
        return buildResponse(401, {
            verified: false,
            message: 'incorrect request body'
        })
    }

    const skater = requestBody.skater;
    const token = requestBody.token;
    // use verifyToken in auth to verify the skater and token
    const verification = verifyToken(skater.derbyName, token);

    // process verification
    if (!verification.verified){
        return buildResponse(401, verification);
    }

    return buildResponse(200, {
        verified: true,
        message: 'success',
        skater: skater,
        token: token
    })
}

// module.exports.verify = verify;
export { verify as verify};