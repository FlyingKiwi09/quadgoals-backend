
// defining variables from AWS
import AWS from 'aws-sdk';

AWS.config.update({
    region: 'ap-southeast-2'
})

import {buildResponse} from '../utils/util.js';
// for encrypting password
import bcrypt from 'bcryptjs';

const dynamodb = new AWS.DynamoDB.DocumentClient();
const skatersTable = 'skaters';

async function register(skaterInfo) {
    const derbyName = skaterInfo.derbyName;
    const email = skaterInfo.email;
    const password = skaterInfo.password;

    // check all fields have been filled in
    if (!derbyName || !email || !password){
        return buildResponse(401, {
            message: 'All fields are required'
        })
    }

    const dynamoUser = await getUser(derbyName);
    if (dynamoUser && dynamoUser.derbyName) {
        return buildResponse(401, {
            message: 'derbyname unavailable'
        })
    }

    // trim and encrypt the password
    const encryptedPW = bcrypt.hashSync(password.trim(), 10);

    // define skater so they can be saved to the database
    const skater = {
        derbyName: derbyName,
        email: email,
        password: encryptedPW
    }

    const saveSkaterResponse = await saveUser(skater);
    if (!saveSkaterResponse) {
        return buildResponse(503, { message: 'Server Error. Please try again later.'})
    }

    return buildResponse(200, { derbyName: derbyName});

}

// get the derbyName from the dynamodb table
async function getUser(derbyName) {
    const params = {
        TableName: skatersTable,
        Key: {
            derbyName: derbyName
        }
    }

    return await dynamodb.get(params).promise().then(response => {
        return response.Item;
    }, error => {
        console.error('There is an error getting user: ', error);
    })
}

// save skater funciton
async function saveUser(skater) {
    const params = {
        TableName: skatersTable,
        Item: skater
    }

    return await dynamodb.put(params).promise().then(() => {
        return true;
    }, error => {
        console.error('There is an error saving user: ', error);
    })
}

// module.exports.register = register;
export { register as register};