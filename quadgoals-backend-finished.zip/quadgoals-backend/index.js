// import the modules for each page 
// 
import {register} from './service/register.js';
import {login} from './service/login.js';
import {verify} from './service/verify.js';
import {buildResponse} from './utils/util.js';

// require doesn't work in commonjs
// const registerService = require('./service/register');
// const loginService = require('./service/login');
// const verifyService = require('./service/verify');
// const util = require('./utils/util');

// paths for the navLinks
const healthPath = '/health';
const registerPath = '/register';
const loginPath = '/login';
const verifyPath = '/verify';

//  switch statement filters the httpMethod and event path to the path
export const handler = async(event) => {
  console.log('Request Event: ', event);
  let response;
  switch(true){
        case event.httpMethod === 'GET' && event.path === healthPath:
            response = buildResponse(200, 'health test ok');
            break;
        case event.httpMethod === 'POST' && event.path === registerPath:
            // extract the body of the event
            const registerBody = JSON.parse(event.body);
            // async function becasue it's dealing with dynamodb
            response = await register(registerBody);
            break;
        case event.httpMethod === 'POST' && event.path === loginPath:
            // extract the body of the event
            const loginBody = JSON.parse(event.body);
            response = await login(loginBody);
            break;
        case event.httpMethod === 'POST' && event.path === verifyPath:
            const verifyBody = JSON.parse(event.body);
            response = verify(verifyBody);
            break;
        default:
            response = buildResponse(404, '404 Not Found');
  }
  return response;
};


