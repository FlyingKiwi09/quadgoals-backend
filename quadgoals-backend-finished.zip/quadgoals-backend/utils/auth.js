
// create a token for the user
import jwt from 'jsonwebtoken';

function generateToken(skaterInfo){
    if (!skaterInfo){
        return null;
    }

    return jwt.sign(skaterInfo, process.env.JWT_SECRET, {
        expiresIn: '1h'
    })
}

function verifyToken(derbyName, token) {
    return jwt.verify(token, process.env.JWT_SECRET, (error, response) => {
        // if the token is invalid
        if (error) {
            return {
                verified: false,
                message: 'invalid token'
            }
        }

        // if the username (skaters derby name) is invalid
        if (response.derbyName !== derbyName) {
            return {
                verified: false,
                message: 'invalid skater'
            }
        }

        // if both are valid
        return {
            verified: true,
            message: 'verified'
        }
    })
}

// module.exports.generateToken = generateToken;
// module.exports.verifyToken = verifyToken;

export { generateToken as generateToken }; 
export { verifyToken as verifyToken }; 